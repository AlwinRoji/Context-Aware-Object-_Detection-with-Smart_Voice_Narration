document.getElementById("loginBtn").addEventListener("click", () => {
  const user = document.getElementById("username").value.trim();
  const pass = document.getElementById("password").value.trim();

  fetch("users.json")
    .then(res => res.json())
    .then(users => {
      const found = users.find(u => u.username === user && u.password === pass);
      if (found) {
        localStorage.setItem("loggedInUser", user);
        window.location.href = "index.html";
      } else {
        document.getElementById("loginMsg").textContent = "❌ Invalid credentials.";
      }
    });
});
