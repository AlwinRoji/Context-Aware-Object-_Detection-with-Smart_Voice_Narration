const express = require("express");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

const DATA_FILE = path.join(__dirname, "data.json");
const USERS_FILE = path.join(__dirname, "users.json");

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (!fs.existsSync(USERS_FILE)) return res.status(404).json({ error: "users.json not found" });

  const users = JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    res.json({ success: true, name: user.Passenger_Name });
  } else {
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

app.get("/bookings", (req, res) => {
  try {
    if (!fs.existsSync(DATA_FILE)) return res.json([]);
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Error reading data.json" });
  }
});

app.post("/saveBooking", (req, res) => {
  const newBookings = req.body;
  if (!Array.isArray(newBookings)) return res.status(400).json({ error: "Invalid booking format" });

  try {
    const existing = fs.existsSync(DATA_FILE)
      ? JSON.parse(fs.readFileSync(DATA_FILE, "utf8"))
      : [];

    let maxId = existing.reduce((max, b) => Math.max(max, b.Booking_ID || 0), 0);

    const updatedBookings = newBookings.map((b, idx) => ({
      Booking_ID: maxId + idx + 1,
      Passenger_Name: b.Passenger_Name || "Guest",
      Seat_No: b.Seat_No,
      From_Stop: b.From_Stop,
      To_Stop: b.To_Stop,
      Timestamp: b.Timestamp || new Date().toISOString()
    }));

    const finalData = [...existing, ...updatedBookings];
    fs.writeFileSync(DATA_FILE, JSON.stringify(finalData, null, 2));

    console.log(`Saved ${updatedBookings.length} booking(s).`);
    res.json({ success: true, count: updatedBookings.length });
  } catch (err) {
    console.error("❌ Error saving booking:", err);
    res.status(500).json({ error: "Failed to save booking" });
  }
});

app.get("/myBookings/:username", (req, res) => {
  const username = req.params.username.toLowerCase();
  try {
    if (!fs.existsSync(DATA_FILE)) return res.json([]);

    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    const userBookings = data.filter(
      b => (b.Passenger_Name || "").toLowerCase() === username
    );

    res.json(userBookings);
  } catch (err) {
    console.error("❌ Error fetching bookings:", err);
    res.status(500).json({ error: "Failed to read bookings" });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚍 Server running at http://localhost:${PORT}`));
