const loggedUser = localStorage.getItem("loggedInUser");
if (!loggedUser) {
  window.location.href = "login.html";
} else {
  document.getElementById("welcomeUser").textContent = `👋 Welcome, ${loggedUser}`;
  document.getElementById("logoutBtn").onclick = () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "login.html";
  };
}

function loadMyBookings() {
  const user = localStorage.getItem("loggedInUser");
  if (!user) return;

  fetch(`/myBookings/${user}`)
    .then(res => res.json())
    .then(bookings => {
      const list = document.getElementById("myBookingsList");
      list.innerHTML = "";

      if (!bookings.length) {
        list.innerHTML = "<li>No bookings yet.</li>";
        return;
      }

      bookings.forEach(b => {
        const li = document.createElement("li");
        li.textContent = `Seat ${b.Seat_No}: ${b.From_Stop} → ${b.To_Stop}`;
        list.appendChild(li);
      });
    })
    .catch(err => console.error("Error loading bookings:", err));
}

loadMyBookings();


const stops = ["Ahmedabad", "Bengaluru", "Chennai", "Delhi", "Ernakulam", "Faridabad", "Gurugram"];
const rows = ["A","B","C","D","E","F","G","H","I","J"];
const cols = [1,2,3,4];
let data = [];

const fromStop = document.getElementById("fromStop");
const toStop = document.getElementById("toStop");
const busLayout = document.getElementById("busLayout");
const checkSeatsBtn = document.getElementById("checkSeats");
const infoText = document.getElementById("infoText");
const suggestionBox = document.getElementById("suggestionBox");
const suggestedSeatsList = document.getElementById("suggestedSeats");
const fareBox = document.getElementById("fareBreakdown");
const fareBase = document.getElementById("fareBase");
const fareDiscount = document.getElementById("fareDiscount");
const fareTotal = document.getElementById("fareTotal");
const confirmBookingBtn = document.getElementById("confirmBooking");

let selectedSeat = null;
let currentFrom = null;
let currentTo = null;
let lastSuggestion = null;

stops.forEach(stop => {
  fromStop.innerHTML += `<option value="${stop}">${stop}</option>`;
  toStop.innerHTML += `<option value="${stop}">${stop}</option>`;
});

rows.forEach(r => {
  cols.forEach(c => {
    const seat = document.createElement("div");
    seat.classList.add("seat", "free");
    seat.id = `${r}${c}`;
    seat.textContent = `${r}${c}`;
    busLayout.appendChild(seat);
  });
});

function loadAllBookingsToMemory() {
  return fetch("/bookings")
    .then(res => res.json())
    .then(json => {
      data = json || [];
      return data;
    })
    .catch(err => {
      console.error("Failed to fetch bookings:", err);
      data = [];
      return [];
    });
}

loadAllBookingsToMemory();

checkSeatsBtn.addEventListener("click", () => {
  const from = fromStop.value;
  const to = toStop.value;

  if (stops.indexOf(from) >= stops.indexOf(to)) {
    alert("Invalid stop selection!");
    return;
  }

  currentFrom = from;
  currentTo = to;
  updateSeats(from, to);
});

function updateSeats(from, to) {
  document.querySelectorAll(".seat").forEach(seat => {
    seat.className = "seat free";
    seat.onclick = null;
    seat.removeAttribute("title");
  });

  infoText.textContent = "Select a yellow seat to see details.";
  suggestionBox.classList.add("hidden");
  fareBox.classList.add("hidden");

  const reqFrom = stops.indexOf(from);
  const reqTo = stops.indexOf(to);

  rows.forEach(r => {
    cols.forEach(c => {
      const seatId = `${r}${c}`;
      const bookings = data.filter(b => b.Seat_No === seatId);
      let seatStatus = "free";
      let freeNote = "";

      const bookedRanges = bookings.map(b => ({
        from: stops.indexOf(b.From_Stop),
        to: stops.indexOf(b.To_Stop),
        passenger: b.Passenger_Name
      }));

      bookedRanges.sort((a, b) => a.from - b.from);
      let merged = [];
      for (const range of bookedRanges) {
        if (!merged.length) merged.push({ ...range });
        else {
          let last = merged[merged.length - 1];
          if (range.from <= last.to) {
            last.to = Math.max(last.to, range.to);
          } else merged.push({ ...range });
        }
      }

      for (const bk of merged) {
        const overlap = !(reqTo <= bk.from || reqFrom >= bk.to);
        if (reqFrom >= bk.from && reqTo <= bk.to) {
          seatStatus = "booked";
          const firstBooking = bookings[0];
          if (firstBooking) {
            const owner = firstBooking.Passenger_Name || "";
            document.getElementById(seatId).setAttribute("title", `${seatId} — Booked by ${owner} (${firstBooking.From_Stop} → ${firstBooking.To_Stop})`);
          }
          break;
        } else if (overlap) {
          seatStatus = "partial";
          if (reqFrom < bk.from)
            freeNote = `Free from ${from} → ${stops[bk.from]}`;
          else if (reqTo > bk.to)
            freeNote = `Free from ${stops[bk.to]} → ${to}`;
        }
      }

      const seatEl = document.getElementById(seatId);
      if (seatStatus === "booked") {
        seatEl.classList.replace("free", "booked");
      } else if (seatStatus === "partial") {
        seatEl.classList.replace("free", "partial");
        if (freeNote) seatEl.onclick = () => showSeatDetails(seatId, freeNote);
      } else {
        seatEl.onclick = () => {
          selectedSeat = seatId;
          infoText.textContent = `Seat ${seatId} — Fully free for selected route`;
          suggestionBox.classList.add("hidden");
          fareBox.classList.remove("hidden");
          const tripStops = Math.abs(stops.indexOf(currentTo) - stops.indexOf(currentFrom));
          const { base, discount, total } = calculateFareDetailed(tripStops, 1);
          fareBase.textContent = `Base Fare: ₹${base}`;
          fareDiscount.textContent = `Discount: -₹${discount}`;
          fareTotal.textContent = `Total Fare: ₹${total}`;
        };
      }
    });
  });
}

function isSeatFreeForSegment(seatId, segFromIdx, segToIdx) {
  const bookings = data.filter(b => b.Seat_No === seatId);
  for (const b of bookings) {
    const bFrom = stops.indexOf(b.From_Stop);
    const bTo = stops.indexOf(b.To_Stop);
    const overlap = !(segToIdx <= bFrom || segFromIdx >= bTo);
    if (overlap) return false;
  }
  return true;
}

function computeFreeIntervals(seatId, reqFromIdx, reqToIdx) {
  const bookings = data
    .filter(b => b.Seat_No === seatId)
    .map(b => ({ from: stops.indexOf(b.From_Stop), to: stops.indexOf(b.To_Stop) }))
    .filter(iv => !(iv.to <= reqFromIdx || iv.from >= reqToIdx))
    .sort((a,b) => a.from - b.from);

  const free = [];
  let cur = reqFromIdx;
  for (const bk of bookings) {
    if (cur < bk.from) free.push({ from: cur, to: Math.min(bk.from, reqToIdx) });
    cur = Math.max(cur, bk.to);
    if (cur >= reqToIdx) break;
  }
  if (cur < reqToIdx) free.push({ from: cur, to: reqToIdx });
  return free.filter(iv => iv.to > iv.from);
}

function getSegmentAwareSuggestions(clickedSeat, reqFromIdx, reqToIdx, freeInterval) {
  let compFrom = null, compTo = null;
  if (freeInterval.from > reqFromIdx) { compFrom = reqFromIdx; compTo = freeInterval.from; }
  else if (freeInterval.to < reqToIdx) { compFrom = freeInterval.to; compTo = reqToIdx; }
  else return [];

  const [baseRow, baseCol] = [clickedSeat[0], parseInt(clickedSeat[1])];
  const suggestions = [];

  rows.forEach(r => {
    cols.forEach(c => {
      const id = `${r}${c}`;
      if (id === clickedSeat) return;
      if (isSeatFreeForSegment(id, compFrom, compTo)) {
        const distance = Math.abs(rows.indexOf(r) - rows.indexOf(baseRow)) + Math.abs(c - baseCol);
        const sameRowBonus = (r === baseRow) ? 30 : 0;
        const proximity = Math.max(0, 20 - distance * 6);
        const windowBonus = (c === 1 || c === 4) ? 4 : 0;
        const frontBonus = (["A","B","C"].includes(r)) ? 2 : 0;
        const score = sameRowBonus + proximity + windowBonus + frontBonus;
        suggestions.push({ id, score, compFrom, compTo });
      }
    });
  });

  return suggestions.sort((a,b) => b.score - a.score).slice(0,3);
}

function showSeatDetails(seatId, note) {
  selectedSeat = seatId;
  infoText.textContent = `Seat ${seatId} — ${note}`;
  const reqFromIdx = stops.indexOf(currentFrom);
  const reqToIdx = stops.indexOf(currentTo);

  const freeIntervals = computeFreeIntervals(seatId, reqFromIdx, reqToIdx);
  if (!freeIntervals.length) return;

  const freeInterval = freeIntervals.reduce((a,b)=>( (b.to - b.from) > (a.to - a.from) ? b : a ));
  const suggestions = getSegmentAwareSuggestions(seatId, reqFromIdx, reqToIdx, freeInterval);
  suggestedSeatsList.innerHTML = "";
  lastSuggestion = null;

  if (suggestions.length) {
    suggestions.forEach(s => {
      const compFrom = stops[s.compFrom];
      const compTo = stops[s.compTo];
      const mainFrom = stops[freeInterval.from];
      const mainTo = stops[freeInterval.to];
      const li = document.createElement("li");

      const isPartialFirst = freeInterval.from === reqFromIdx;

      if (isPartialFirst) {
        li.innerHTML = `
          ${seatId}: ${mainFrom} → ${mainTo}
          <br>then <strong style="font-size:1.1em;">${s.id}: ${compFrom} → ${compTo}</strong>
        `;
      } else {
        li.innerHTML = `
          <strong style="font-size:1.1em;">${s.id}: ${compFrom} → ${compTo}</strong>
          <br><small>then ${seatId}: ${mainFrom} → ${mainTo}</small>
        `;
      }

      li.onclick = () => {
        document.querySelectorAll("#suggestedSeats li").forEach(x => x.style.outline = "");
        li.style.outline = "2px solid #1f4e79";
        lastSuggestion = s;

        document.querySelectorAll(".seat").forEach(x => x.classList.remove("selected"));
        const suggestedEl = document.getElementById(s.id);
        const clickedEl = document.getElementById(seatId);
        if (suggestedEl) suggestedEl.classList.add("selected");
        if (clickedEl) clickedEl.classList.add("selected");

        const tripStops = Math.abs(reqToIdx - reqFromIdx);
        const { base, discount, total } = calculateFareDetailed(tripStops, 2);
        fareBase.textContent = `Base Fare: ₹${base}`;
        fareDiscount.textContent = `Discount: -₹${discount}`;
        fareTotal.textContent = `Total Fare: ₹${total}`;
        fareBox.classList.remove("hidden");
      };

      suggestedSeatsList.appendChild(li);
    });

    suggestionBox.classList.remove("hidden");
  } else {
    suggestionBox.classList.add("hidden");
  }

  const tripStops = Math.abs(reqToIdx - reqFromIdx);
  const {base,discount,total} = calculateFareDetailed(tripStops,1);
  fareBase.textContent = `Base Fare: ₹${base}`;
  fareDiscount.textContent = `Discount: -₹${discount}`;
  fareTotal.textContent = `Total Fare: ₹${total}`;
  fareBox.classList.remove("hidden");
}

function calculateFareDetailed(tripStops, seatChanges) {
  const baseFarePerStop = 150;
  let base = tripStops * baseFarePerStop;
  let discount = 0;
  if (seatChanges > 1) discount = base * 0.15;
  else if (tripStops < 6) discount = base * 0.1;
  const total = Math.round(base - discount);
  return {base,discount:Math.round(discount),total};
}

confirmBookingBtn.onclick = async () => {
  if (!selectedSeat) return alert("Select a seat first!");

  const now = Date.now();
  const reqFromIdx = stops.indexOf(currentFrom);
  const reqToIdx = stops.indexOf(currentTo);
  const tripStops = Math.abs(reqToIdx - reqFromIdx);
  const seatEl = document.getElementById(selectedSeat);
  const isPartialSeat = seatEl.classList.contains("partial");

  if (isPartialSeat && !lastSuggestion) {
    const proceed = confirm(
      "⚠️ This seat covers only part of your journey.\n\nDo you wish to continue with this seat?"
    );
    if (!proceed) {
      infoText.textContent = "Booking cancelled. Please choose another seat.";
      return;
    }
  }

  let bookingsToSave = [];
  if (lastSuggestion) {
    bookingsToSave.push(
      {
        Passenger_Name: loggedUser,
        Seat_No: lastSuggestion.id,
        From_Stop: stops[lastSuggestion.compFrom],
        To_Stop: stops[lastSuggestion.compTo],
        Timestamp: new Date().toISOString()
      },
      {
        Passenger_Name: loggedUser,
        Seat_No: selectedSeat,
        From_Stop: stops[lastSuggestion.compTo],
        To_Stop: stops[reqToIdx],
        Timestamp: new Date().toISOString()
      }
    );
  } else {
    bookingsToSave.push({
      Passenger_Name: loggedUser,
      Seat_No: selectedSeat,
      From_Stop: currentFrom,
      To_Stop: currentTo,
      Timestamp: new Date().toISOString()
    });
  }

  try {
    const res = await fetch("/saveBooking", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bookingsToSave)
    });
    if (!res.ok) throw new Error("Server error");
  } catch (err) {
    console.error("Save failed:", err);
    alert("Booking confirmed locally, but failed to save in data.json");
  }

  try {
    await loadAllBookingsToMemory();
    updateSeats(currentFrom, currentTo);
  } catch (err) {
    console.error("Failed to reload booking data:", err);
  }

  const selectedEl = document.getElementById(selectedSeat);
  if (selectedEl && selectedEl.classList.contains("partial")) selectedEl.classList.replace("partial", "booked");
  if (lastSuggestion) {
    const sugEl = document.getElementById(lastSuggestion.id);
    if (sugEl && sugEl.classList.contains("free")) sugEl.classList.replace("free", "booked");
  }

  infoText.textContent = `Booking confirmed for ${selectedSeat}${lastSuggestion ? " + " + lastSuggestion.id : ""}`;

  loadMyBookings();
  suggestionBox.classList.add("hidden");
  fareBox.classList.add("hidden");
  document.querySelectorAll(".seat").forEach(s => s.classList.remove("selected"));
  lastSuggestion = null;
};
