# Bus Seat Optimization

A web application for optimizing bus seat assignments with user authentication.

## Features

- User login and authentication
- Bus seat optimization interface
- Data management for users and seat assignments

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd bus-seat-optimization
   ```

2. Install dependencies:
   ```
   npm install
   ```

## Usage

Start the server:
```
node server.js
```

The application will run on `http://localhost:3000` (assuming default Express port).

## Technologies Used

- **Backend**: Node.js, Express.js
- **Frontend**: HTML, CSS, JavaScript
- **Data**: JSON files for storage

## Project Structure

- `server.js`: Main server file
- `login.js`: Login functionality
- `script.js`: Client-side scripts
- `index.html`: Main application page
- `login.html`: Login page
- `style.css`: Stylesheets
- `data.json`: Seat data
- `users.json`: User data

## License

MIT